<?php
/**
 * Content wrappers
 *
 * @author           WooThemes
 * @package          WooCommerce/Templates
 * @version          3.3.0
 * @flatsome-version 3.16.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
</div><!-- shop container -->
